# payroll/decorators.py

from django.contrib.auth.decorators import user_passes_test

def is_admin(user):
    """
    Checks if a user is an admin (a superuser).
    """
    return user.is_authenticated and user.is_superuser

def is_employee(user):
    """
    Checks if a user is an employee (not a superuser).
    """
    return user.is_authenticated and not user.is_superuser

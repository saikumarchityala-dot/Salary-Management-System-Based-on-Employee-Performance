# payroll/models.py

from django.db import models
from django.contrib.auth.models import User
from datetime import date

class Employee(models.Model):
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    employee_id = models.CharField(max_length=20, unique=True)
    date_of_joining = models.DateField(default=date.today)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    department = models.CharField(max_length=100)
    address = models.TextField(blank=True, null=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True, null=True)
    profile_image = models.ImageField(upload_to='profile_pics/', blank=True, null=True)
    designation = models.CharField(max_length=100, blank=True, null=True)
    basic_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name}"

class Attendance(models.Model):
    ATTENDANCE_CHOICES = (
        ('P', 'Present'),
        ('A', 'Absent'),
        ('L', 'Leave'),
        ('H', 'Half-day')
    )
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    date = models.DateField(default=date.today)
    status = models.CharField(max_length=1, choices=ATTENDANCE_CHOICES)
    
    def __str__(self):
        return f"{self.employee.user.first_name} - {self.date} - {self.get_status_display()}"
        
    class Meta:
        unique_together = ('employee', 'date')

class SalarySlip(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    pay_period_start = models.DateField()
    pay_period_end = models.DateField()
    basic_salary = models.DecimalField(max_digits=10, decimal_places=2) 
    bonus = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    incentive = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    hra = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    # --- NEW FIELDS ---
    overtime_hours = models.PositiveIntegerField(default=0)
    overtime_pay = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    orders_processed = models.PositiveIntegerField(default=0)
    order_bonus = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    net_salary = models.DecimalField(max_digits=10, decimal_places=2)
    performance_rating = models.IntegerField(default=5)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Salary for {self.employee.user.first_name} ({self.pay_period_end.strftime('%B %Y')})"
    
    def save(self, *args, **kwargs):
        # --- UPDATED NET SALARY CALCULATION ---
        total_earnings = (
            self.basic_salary + self.hra + self.bonus + 
            self.incentive + self.overtime_pay + self.order_bonus
        )
        self.net_salary = total_earnings - self.deductions
        super().save(*args, **kwargs)

class Leave(models.Model):
    STATUS_CHOICES = (
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('R', 'Rejected'),
    )
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    status = models.CharField(max_length=1, choices=STATUS_CHOICES, default='P')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Leave for {self.employee.user.first_name} from {self.start_date} to {self.end_date}"
    
class Announcement(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

# payroll/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import get_user_model
from django.db import IntegrityError
from django.urls import reverse
from django.utils import timezone
from datetime import timedelta, date
from django.contrib.auth.forms import AuthenticationForm
from django.db.models import Sum
from decimal import Decimal
from .models import Employee, Attendance, SalarySlip,Leave,Announcement
import pandas as pd
import calendar
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

User = get_user_model()

def is_admin(user):
    return user.is_authenticated and user.is_superuser

def is_employee(user):
    return user.is_authenticated and not user.is_superuser
def home_view(request):
    if request.user.is_authenticated:
        return redirect('admin_dashboard' if request.user.is_superuser else 'employee_dashboard')
    return render(request, 'home.html')

def about_us_view(request):
    if request.user.is_authenticated:
        return redirect('admin_dashboard' if request.user.is_superuser else 'employee_dashboard')
    return render(request, 'about_us.html')

def contact_us_view(request):
    if request.user.is_authenticated:
        return redirect('admin_dashboard' if request.user.is_superuser else 'employee_dashboard')
    return render(request, 'contact_us.html')
def login_view(request):
    if request.user.is_authenticated:
        return redirect('admin_dashboard' if request.user.is_superuser else 'employee_dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('admin_dashboard' if user.is_superuser else 'employee_dashboard')
        else:
            messages.error(request, "Invalid credentials.")
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

@login_required
def custom_logout_view(request):
    logout(request)
    return redirect('login')

@login_required
@user_passes_test(is_employee)
def my_salary_slips_view(request):
    employee = get_object_or_404(Employee, user=request.user)
    salary_slips = SalarySlip.objects.filter(employee=employee).order_by('-pay_period_end')
    
    for slip in salary_slips:
        slip.total_earnings = (
            slip.basic_salary + slip.hra + slip.bonus + 
            slip.incentive + slip.overtime_pay + slip.order_bonus
        )

    context = {'salary_slips': salary_slips}
    return render(request, 'my_salary_slips.html', context)

@login_required
@user_passes_test(is_admin)
def view_employees_view(request):
    employees = Employee.objects.all().select_related('user').order_by('user__first_name')
    context = {'employees': employees}
    return render(request, 'view_employees.html', context)

@login_required
@user_passes_test(is_employee)
def my_attendance_view(request):
    employee = get_object_or_404(Employee, user=request.user)
    today = timezone.localdate()

    try:
        year = int(request.GET.get('year', today.year))
        month = int(request.GET.get('month', today.month))
    except ValueError:
        year, month = today.year, today.month

    current_month_date = date(year, month, 1)
    
    prev_month_date = current_month_date - timedelta(days=1)
    next_month_date = (current_month_date + timedelta(days=31)).replace(day=1)

    records = Attendance.objects.filter(
        employee=employee, date__year=year, date__month=month
    )
    
    # --- : Calculate monthly summary stats ---
    total_present = records.filter(status='P').count()
    total_absent = records.filter(status='A').count()
    total_leave = records.filter(status='L').count()
    total_half_day = records.filter(status='H').count()

    attendance_map = {record.date.day: record for record in records}
    month_calendar = calendar.monthcalendar(year, month)
    full_calendar = []
    for week in month_calendar:
        week_data = []
        for day in week:
            if day == 0:
                week_data.append(None)
            else:
                record = attendance_map.get(day)
                week_data.append({
                    'day': day,
                    'status': record.status if record else None,
                    'display': record.get_status_display() if record else None
                })
        full_calendar.append(week_data)

    context = {
        'full_calendar': full_calendar,
        'month_name': current_month_date.strftime('%B'),
        'year': year,
        'prev_year': prev_month_date.year,
        'prev_month': prev_month_date.month,
        'next_year': next_month_date.year,
        'next_month': next_month_date.month,
        'total_present': total_present,
        'total_absent': total_absent,
        'total_leave': total_leave,
        'total_half_day': total_half_day,
    }
    return render(request, 'my_attendance.html', context)




@login_required
@user_passes_test(is_employee)
def salary_slip_detail_view(request, slip_id):
    employee = get_object_or_404(Employee, user=request.user)
    slip = get_object_or_404(SalarySlip, id=slip_id, employee=employee)
    
    total_days = (slip.pay_period_end - slip.pay_period_start).days + 1
    present_days = Attendance.objects.filter(
        employee=employee, 
        date__range=[slip.pay_period_start, slip.pay_period_end],
        status='P'
    ).count()
    
    attendance_percentage = (present_days / total_days) * 100 if total_days > 0 else 0
    
    # ---  total_earnings calculation ---
    slip.total_earnings = (slip.basic_salary + slip.hra + slip.bonus + 
                         slip.incentive + slip.overtime_pay + slip.order_bonus)
    
    incentive_percentage = 0
    if attendance_percentage >= 50:
        incentive_percentage = slip.performance_rating

    context = {
        'slip': slip, 'present_days': present_days, 'total_days': total_days,
        'absent_days': total_days - present_days, 'attendance_percentage': attendance_percentage,
        'incentive_percentage': incentive_percentage,
    }
    return render(request, 'salary_slip_detail.html', context)


@login_required
@user_passes_test(is_admin)
def admin_dashboard_view(request):
    today = timezone.localdate()
    
    # KPI 1: Today's Attendance
    total_employees = Employee.objects.count()
    present_today = Attendance.objects.filter(date=today, status='P').count()
    todays_attendance_percentage = int((present_today / total_employees) * 100) if total_employees > 0 else 0
    
    # KPI 2: Active Employees
    active_employees_count = total_employees
    
    # KPI 3: Total Payroll This Month
    start_of_month = today.replace(day=1)
    payroll_this_month = SalarySlip.objects.filter(pay_period_end__gte=start_of_month).aggregate(total=Sum('net_salary'))
    total_payroll_this_month = (payroll_this_month['total'] or 0) / 100000 # Convert to Lakhs

    # Recent Slips
    recent_slips = SalarySlip.objects.all().order_by('-created_at')[:5]
    
    # On Leave Today
    on_leave_today = Attendance.objects.filter(date=today, status__in=['L','A', 'H']).select_related('employee__user')
    print(on_leave_today)
    context = {
        'todays_attendance_percentage': todays_attendance_percentage,
        'active_employees_count': active_employees_count,
        'total_payroll_this_month': total_payroll_this_month,
        'recent_slips': recent_slips,
        'on_leave_today': on_leave_today,
    }
    return render(request, 'admin_dashboard.html', context)


@login_required
@user_passes_test(is_admin)
def edit_employee_view(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    if request.method == 'POST':
        try:
            full_name = request.POST.get('full_name')
            email = request.POST.get('email')
            employee_id_form = request.POST.get('employee_id')
            designation = request.POST.get('designation')
            department = request.POST.get('department')
            basic_salary = request.POST.get('basic_salary')
            profile_image = request.FILES.get('profile_image')
            
            # Update User model
            name_parts = full_name.split(' ', 1)
            employee.user.first_name = name_parts[0]
            employee.user.last_name = name_parts[1] if len(name_parts) > 1 else ''
            employee.user.email = email
            employee.user.save()
            
            # Update Employee model
            employee.employee_id = employee_id_form
            employee.designation = designation
            employee.department = department
            employee.basic_salary = basic_salary
            if profile_image:
                employee.profile_image = profile_image
            employee.save()
            
            messages.success(request, f"Details for {full_name} updated successfully.")
            return redirect('view_employees')
        except Exception as e:
            messages.error(request, f"An error occurred: {e}")

    return render(request, 'edit_employee.html', {'employee': employee})


@login_required
@user_passes_test(is_admin)
def delete_employee_view(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    if request.method == 'POST':
        # The associated User will be deleted automatically due to on_delete=models.CASCADE
        employee_name = employee.user.get_full_name()
        employee.user.delete()
        messages.success(request, f"Employee {employee_name} has been deleted.")
        return redirect('view_employees')
    
    return render(request, 'delete_employee_confirm.html', {'employee': employee})

@login_required
@user_passes_test(is_admin)
def admin_view_slips_view(request):
    all_employees = Employee.objects.all().order_by('user__first_name')
    selected_employee_id = request.GET.get('employee')
    selected_employee = None
    salary_slips = []

    if selected_employee_id:
        selected_employee = get_object_or_404(Employee, id=selected_employee_id)
        salary_slips = SalarySlip.objects.filter(employee=selected_employee).order_by('-pay_period_end')

    context = {
        'all_employees': all_employees,
        'selected_employee': selected_employee,
        'salary_slips': salary_slips
    }
    return render(request, 'admin_view_slips.html', context)

@login_required
@user_passes_test(is_admin)
def admin_salary_slip_detail_view(request, slip_id):
    slip = get_object_or_404(SalarySlip, id=slip_id)
    employee = slip.employee
    
    total_days = (slip.pay_period_end - slip.pay_period_start).days + 1
    present_days = Attendance.objects.filter(
        employee=employee, 
        date__range=[slip.pay_period_start, slip.pay_period_end],
        status='P'
    ).count()
    
    attendance_percentage = (present_days / total_days) * 100 if total_days > 0 else 0
    slip.total_earnings = (slip.basic_salary + slip.hra + slip.bonus + 
                         slip.incentive + slip.overtime_pay + slip.order_bonus)
    
    incentive_percentage = 0
    if attendance_percentage >= 50:
        incentive_percentage = slip.performance_rating

    context = {
        'slip': slip, 'present_days': present_days, 'total_days': total_days,
        'absent_days': total_days - present_days, 'attendance_percentage': attendance_percentage,
        'incentive_percentage': incentive_percentage,
        'is_admin_view': True # Flag to slightly alter the template if needed
    }
    return render(request, 'admin_salary_slip_detail.html', context)

@login_required
@user_passes_test(is_employee)
def employee_dashboard_view(request):
    try:
        employee = request.user.employee
        today = timezone.localdate()
        
        # KPI 1: This Month's Attendance
        start_of_month = today.replace(day=1)
        # We only count days up to today
        days_in_month_so_far = (today - start_of_month).days + 1
        present_count = Attendance.objects.filter(
            employee=employee,
            date__gte=start_of_month,
            date__lte=today,
            status='P'
        ).count()
        current_month_attendance = int((present_count / days_in_month_so_far) * 100) if days_in_month_so_far > 0 else 0
        
        # KPIs 2 & 3: Latest Salary Slip info
        latest_slip = SalarySlip.objects.filter(employee=employee).order_by('-pay_period_end').first()
        
        # Recent Slips for table
        recent_slips = SalarySlip.objects.filter(employee=employee).order_by('-pay_period_end')[:5]
        
        context = {
            'current_month_attendance': current_month_attendance,
            'latest_slip': latest_slip,
            'recent_slips': recent_slips,
        }
        return render(request, 'employee_dashboard.html', context)
    except Employee.DoesNotExist:
        messages.error(request, "Employee profile not found.")
        logout(request)
        return redirect('login')

@login_required
@user_passes_test(is_admin)
def add_employee_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        full_name = request.POST.get('full_name')
        employee_id = request.POST.get('employee_id')
        gender = request.POST.get('gender')
        designation = request.POST.get('designation')
        department = request.POST.get('department')
        basic_salary = request.POST.get('basic_salary')
        profile_image = request.FILES.get('profile_image')

        if User.objects.filter(username=username).exists():
            messages.error(request, f"A user with the username '{username}' already exists.")
            return render(request, 'add_employee.html')
        if User.objects.filter(email=email).exists():
            messages.error(request, f"A user with the email '{email}' already exists.")
            return render(request, 'add_employee.html')
        if Employee.objects.filter(employee_id=employee_id).exists():
            messages.error(request, f"An employee with the ID '{employee_id}' already exists.")
            return render(request, 'add_employee.html')
        
        try:
            name_parts = full_name.split(' ', 1)
            first_name = name_parts[0]
            last_name = name_parts[1] if len(name_parts) > 1 else ''

            user = User.objects.create_user(
                username=username, email=email, password=password,
                first_name=first_name, last_name=last_name
            )
            Employee.objects.create(
                user=user, employee_id=employee_id, gender=gender,
                designation=designation, department=department,
                basic_salary=basic_salary, profile_image=profile_image
            )
            messages.success(request, f"Employee '{full_name}' created successfully.")
            return redirect('admin_dashboard')
        except Exception as e:
            messages.error(request, f"An unexpected error occurred: {e}")
            
    return render(request, 'add_employee.html')


@login_required
@user_passes_test(is_admin)
def generate_salary_slip_view(request):
    if request.method == 'POST':
        try:
            employee_id = request.POST.get('employee')
            start_date_str = request.POST.get('pay_period_start')
            end_date_str = request.POST.get('pay_period_end')
            
            hra = request.POST.get('hra', '0')
            bonus = request.POST.get('bonus', '0')
            deductions = request.POST.get('deductions', '0')
            # --- GET NEW FIELDS FROM FORM ---
            overtime_hours = int(request.POST.get('overtime_hours', 0))
            orders_processed = int(request.POST.get('orders_processed', 0))

            employee = Employee.objects.get(id=employee_id)
            start_date = timezone.datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = timezone.datetime.strptime(end_date_str, '%Y-%m-%d').date()
            
            if SalarySlip.objects.filter(employee=employee, pay_period_start__lte=end_date, pay_period_end__gte=start_date).exists():
                messages.error(request, "A salary slip for this employee already exists that overlaps with this date range.")
                return redirect('generate_salary_slip')

            # --- ATTENDANCE BASED INCENTIVE (Unchanged) ---
            total_days = (end_date - start_date).days + 1
            present_count = Attendance.objects.filter(employee=employee, date__range=[start_date, end_date], status='P').count()
            attendance_percentage = (present_count / total_days) * 100 if total_days > 0 else 0
            performance_rating = max(5, round(attendance_percentage / 10))
            incentive = Decimal('0.00')
            if attendance_percentage >= 50:
                incentive_percentage = Decimal(performance_rating)
                incentive = employee.basic_salary * (incentive_percentage / Decimal('100'))

            # --- NEW OVERTIME PAY LOGIC ---
            overtime_pay = Decimal('0.00')
            if overtime_hours >= 50:
                overtime_pay = Decimal('5000.00')
            elif overtime_hours >= 40:
                overtime_pay = Decimal('4000.00')
            elif overtime_hours >= 30:
                overtime_pay = Decimal('3000.00')
            elif overtime_hours >= 20:
                overtime_pay = Decimal('2000.00')
            elif overtime_hours >= 10:
                overtime_pay = Decimal('1000.00')
            
            # --- NEW ORDER BONUS LOGIC (e.g., ₹10 per order) ---
            order_bonus = Decimal(orders_processed) * Decimal('10.00')

            SalarySlip.objects.create(
                employee=employee, pay_period_start=start_date, pay_period_end=end_date,
                basic_salary=employee.basic_salary, hra=Decimal(hra), bonus=Decimal(bonus),
                incentive=incentive, deductions=Decimal(deductions), performance_rating=performance_rating,
                # --- SAVE NEW DATA TO THE MODEL ---
                overtime_hours=overtime_hours, overtime_pay=overtime_pay,
                orders_processed=orders_processed, order_bonus=order_bonus
            )
            messages.success(request, f"Salary slip generated for {employee.user.get_full_name()}.")
            return redirect('generate_salary_slip')

        except Exception as e:
            messages.error(request, f"An error occurred: {e}")

    employees = Employee.objects.all().order_by('user__first_name')
    return render(request, 'generate_salary_slip.html', {'employees': employees})
 

@login_required
@user_passes_test(is_employee)
def weekly_earnings_view(request):
    try:
        employee = request.user.employee
        today = timezone.localdate()
        
        # --- Weekly Calculations ---
        start_of_week = today - timedelta(days=today.weekday())
        weekdays_so_far = today.weekday() + 1
        
        weekly_attendance = Attendance.objects.filter(
            employee=employee, 
            date__range=[start_of_week, today]
        )
        days_present = weekly_attendance.filter(status='P').count()
        
        # 1. Base Pay Earned This Week
        daily_salary = employee.basic_salary / 30 
        base_weekly_earnings = daily_salary * Decimal(days_present)
        
        # 2. Consistency Bonus
        consistency_bonus = Decimal('500.00') if days_present == weekdays_so_far and weekdays_so_far > 0 else Decimal('0.00')
        
        # 3. Estimated Productivity Bonus
        last_slip = SalarySlip.objects.filter(employee=employee).order_by('-pay_period_end').first()
        estimated_order_bonus = Decimal('0.00')
        if last_slip and last_slip.orders_processed > 0:
            # Assume a 22 working-day month to estimate daily orders
            daily_orders = last_slip.orders_processed / 22
            estimated_weekly_orders = daily_orders * days_present
            estimated_order_bonus = Decimal(estimated_weekly_orders) * Decimal('10.00') # Using same logic as salary slip

        total_weekly_earnings = base_weekly_earnings + consistency_bonus + estimated_order_bonus
        
        # --- Monthly Projections ---
        start_of_month = today.replace(day=1)
        days_in_month_so_far = (today - start_of_month).days + 1
        
        monthly_present_count = Attendance.objects.filter(
            employee=employee,
            date__gte=start_of_month,
            date__lte=today,
            status='P'
        ).count()
        
        current_month_attendance_perc = (monthly_present_count / days_in_month_so_far) * 100 if days_in_month_so_far > 0 else 0
        
        # Project incentive based on current attendance
        projected_incentive = Decimal('0.00')
        if current_month_attendance_perc >= 50:
            projected_rating = max(5, round(current_month_attendance_perc / 10))
            incentive_percentage = Decimal(projected_rating)
            projected_incentive = employee.basic_salary * (incentive_percentage / Decimal('100'))

        context = {
            'start_of_week': start_of_week,
            'today': today,
            'days_present_this_week': days_present,
            'weekdays_so_far': weekdays_so_far,
            'total_weekly_earnings': total_weekly_earnings,
            'consistency_bonus': consistency_bonus,
            'projected_incentive': projected_incentive,
            'current_month_attendance_perc': current_month_attendance_perc,
        }
        return render(request, 'weekly_earnings.html', context)
    except Employee.DoesNotExist:
        messages.error(request, "Employee profile not found.")
        logout(request)
        return redirect('login')


@login_required
@user_passes_test(is_admin)
def mark_attendance_view(request):
    # Determine the date to show from the URL parameter, default to today
    selected_date_str = request.GET.get('date')
    if selected_date_str:
        try:
            selected_date = timezone.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
        except ValueError:
            messages.error(request, "Invalid date format. Please use YYYY-MM-DD.")
            selected_date = timezone.localdate()
    else:
        selected_date = timezone.localdate()

    if request.method == 'POST':
        # Get the date from a hidden input in the form to ensure we save for the correct day
        form_date_str = request.POST.get('attendance_date')
        form_date = timezone.datetime.strptime(form_date_str, '%Y-%m-%d').date()

        all_employees = Employee.objects.all()
        for employee in all_employees:
            status = request.POST.get(f'status_{employee.id}')
            if status:
                # Use update_or_create to either update or create the record
                Attendance.objects.update_or_create(
                    employee=employee,
                    date=form_date,
                    defaults={'status': status}
                )
        messages.success(request, f"Attendance for {form_date.strftime('%B %d, %Y')} has been saved successfully.")
        return redirect(f"{request.path}?date={form_date_str}") # Redirect back to the same date

    # For a GET request, fetch existing data to pre-fill the form
    employees = Employee.objects.all().order_by('user__first_name')
    existing_records = Attendance.objects.filter(date=selected_date)
    
    # Prepare data for the template to easily check current status
    employee_attendance_data = []
    for emp in employees:
        current_status = 'P'  # Default to Present if no record exists
        for record in existing_records:
            if record.employee_id == emp.id:
                current_status = record.status
                break
        employee_attendance_data.append({
            'employee': emp,
            'status': current_status
        })

    context = {
        'employee_attendance_data': employee_attendance_data,
        'selected_date': selected_date,
    }
    return render(request, 'mark_attendance.html', context)



@login_required
@user_passes_test(is_admin)
def view_attendance_view(request):
    selected_date_str = request.GET.get('date')
    
    if selected_date_str:
        try:
            selected_date = timezone.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
        except ValueError:
            messages.error(request, "Invalid date format. Please use YYYY-MM-DD.")
            selected_date = timezone.localdate()
    else:
        selected_date = timezone.localdate()

    attendance_records = Attendance.objects.filter(date=selected_date).order_by('employee__user__first_name')

    context = {
        'selected_date': selected_date,
        'attendance_records': attendance_records,
    }
    return render(request, 'view_attendance.html', context)

@login_required
@user_passes_test(is_employee)
def my_profile_view(request):
    employee = get_object_or_404(Employee, user=request.user)
    context = {'employee': employee}
    return render(request, 'my_profile.html', context)


@login_required
@user_passes_test(is_admin)
def predict_salary_view(request):
    employees = Employee.objects.all()
    predictions = []

    for employee in employees:
        salary_slips = SalarySlip.objects.filter(employee=employee).order_by('pay_period_end')
        
        if salary_slips.count() < 2:
            continue

        try:
            last_slip = salary_slips.last()
            
            data = {
                'basic_salary': [float(s.basic_salary) for s in salary_slips],
                'hra': [float(s.hra) for s in salary_slips],
                'bonus': [float(s.bonus) for s in salary_slips],
                'incentive': [float(s.incentive) for s in salary_slips],
                'deductions': [float(s.deductions) for s in salary_slips],
                'net_salary': [float(s.net_salary) for s in salary_slips],
            }
            df = pd.DataFrame(data)

            X = df[['basic_salary', 'hra', 'bonus', 'incentive', 'deductions']]
            y = df['net_salary']

            model = LinearRegression()
            model.fit(X, y)

            # --- IMPROVED PREDICTION LOGIC ---
            # Calculate the average change (trend) for each feature
            diff_df = df.diff().dropna() # Get the difference between each row
            avg_change = diff_df.mean()
            
            # Forecast next month's features by adding the average change to the last known values
            last_features = df.iloc[-1]
            next_month_features_series = last_features + avg_change
            
            # Basic salary usually doesn't change, so we keep it constant
            next_month_features_series['basic_salary'] = last_features['basic_salary']
            
            # Convert series to DataFrame for prediction
            next_month_df = pd.DataFrame([next_month_features_series])

            predicted_salary = model.predict(next_month_df[['basic_salary', 'hra', 'bonus', 'incentive', 'deductions']])[0]
            
            predictions.append({
                'employee_name': employee.user.get_full_name(),
                'predicted_salary': predicted_salary,
                'last_salary': last_slip.net_salary,
                'last_period_start': last_slip.pay_period_start,
                'last_period_end': last_slip.pay_period_end,
            })
        except Exception as e:
            print(f"Could not predict for {employee.user.get_full_name()}: {e}")

    context = {'predictions': predictions}
    return render(request, 'predict_salary.html', context)

@login_required
@user_passes_test(is_employee)
def my_salary_prediction_view(request):
    employee = get_object_or_404(Employee, user=request.user)
    salary_slips = SalarySlip.objects.filter(employee=employee).order_by('pay_period_end')
    prediction = None

    if salary_slips.count() >= 2:
        try:
            last_slip = salary_slips.last()
            
            data = {
                'basic_salary': [float(s.basic_salary) for s in salary_slips],
                'hra': [float(s.hra) for s in salary_slips],
                'bonus': [float(s.bonus) for s in salary_slips],
                'incentive': [float(s.incentive) for s in salary_slips],
                'deductions': [float(s.deductions) for s in salary_slips],
                'net_salary': [float(s.net_salary) for s in salary_slips],
            }
            df = pd.DataFrame(data)

            X = df[['basic_salary', 'hra', 'bonus', 'incentive', 'deductions']]
            y = df['net_salary']

            model = LinearRegression()
            model.fit(X, y)

            diff_df = df.diff().dropna()
            avg_change = diff_df.mean()
            
            last_features = df.iloc[-1]
            next_month_features_series = last_features + avg_change
            next_month_features_series['basic_salary'] = last_features['basic_salary']
            
            next_month_df = pd.DataFrame([next_month_features_series])
            predicted_salary = model.predict(next_month_df[['basic_salary', 'hra', 'bonus', 'incentive', 'deductions']])[0]
            
            prediction = {
                'predicted_salary': predicted_salary,
                'last_salary': last_slip.net_salary,
                'last_period_end': last_slip.pay_period_end,
            }
        except Exception as e:
            print(f"Could not predict salary for {employee.user.get_full_name()}: {e}")

    context = {'prediction': prediction}
    return render(request, 'my_salary_prediction.html', context)

@login_required
@user_passes_test(is_admin)
def delete_salary_slip_view(request, slip_id):
    slip = get_object_or_404(SalarySlip, id=slip_id)
    employee_id = slip.employee.id # Save employee ID for the redirect URL
    
    if request.method == 'POST':
        slip.delete()
        messages.success(request, "The salary slip has been deleted successfully.")
        # Redirect back to the list of slips for the specific employee
        return redirect(f"{reverse('admin_view_slips')}?employee={employee_id}")
    
    return render(request, 'delete_slip_confirm.html', {'slip': slip})


@login_required
@user_passes_test(is_employee)
def apply_leave_view(request):
    employee = get_object_or_404(Employee, user=request.user)
    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        reason = request.POST.get('reason')

        if not all([start_date, end_date, reason]):
            messages.error(request, "Please fill in all fields.")
            return redirect('apply_leave')
        
        try:
            start_date_obj = timezone.datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date_obj = timezone.datetime.strptime(end_date, '%Y-%m-%d').date()

            if start_date_obj > end_date_obj:
                messages.error(request, "Start date cannot be after the end date.")
                return redirect('apply_leave')
            
            Leave.objects.create(
                employee=employee,
                start_date=start_date_obj,
                end_date=end_date_obj,
                reason=reason
            )
            messages.success(request, "Your leave application has been submitted successfully.")
            return redirect('leave_history')
        except ValueError:
            messages.error(request, "Invalid date format.")

    return render(request, 'apply_leave.html')

@login_required
@user_passes_test(is_employee)
def leave_history_view(request):
    employee = get_object_or_404(Employee, user=request.user)
    leaves = Leave.objects.filter(employee=employee).order_by('-created_at')
    return render(request, 'leave_history.html', {'leaves': leaves})


@login_required
@user_passes_test(is_admin)
def manage_leaves_view(request):
    # Fetch all leave requests, ordered by status (Pending first) and then by date
    leaves = Leave.objects.all().order_by('status', '-created_at')
    return render(request, 'manage_leaves.html', {'leaves': leaves})


@login_required
@user_passes_test(is_admin)
def approve_leave_view(request, leave_id):
    leave = get_object_or_404(Leave, id=leave_id)
    if leave.status == 'P': # Only approve if it's pending
        leave.status = 'A'
        leave.save()

        # --- Automatically update attendance records ---
        current_date = leave.start_date
        while current_date <= leave.end_date:
            Attendance.objects.update_or_create(
                employee=leave.employee,
                date=current_date,
                defaults={'status': 'L'} # 'L' for Leave
            )
            current_date += timedelta(days=1)
        
        messages.success(request, f"Leave for {leave.employee.user.get_full_name()} has been approved.")
    else:
        messages.warning(request, "This leave request has already been actioned.")
        
    return redirect('manage_leaves')


@login_required
@user_passes_test(is_admin)
def reject_leave_view(request, leave_id):
    leave = get_object_or_404(Leave, id=leave_id)
    if leave.status == 'P': # Only reject if it's pending
        leave.status = 'R'
        leave.save()
        messages.success(request, f"Leave for {leave.employee.user.get_full_name()} has been rejected.")
    else:
        messages.warning(request, "This leave request has already been actioned.")

    return redirect('manage_leaves')



@login_required
def view_announcements_view(request):
    announcements = Announcement.objects.all().order_by('-created_at')
    return render(request, 'announcements.html', {'announcements': announcements})

@login_required
@user_passes_test(is_admin)
def create_announcement_view(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        if title and content:
            Announcement.objects.create(author=request.user, title=title, content=content)
            messages.success(request, "Announcement posted successfully.")
            return redirect('view_announcements')
        else:
            messages.error(request, "Title and content are required.")
    return render(request, 'create_announcement.html')

@login_required
@user_passes_test(is_admin)
def delete_announcement_view(request, announcement_id):
    announcement = get_object_or_404(Announcement, id=announcement_id)
    if request.method == 'POST':
        announcement.delete()
        messages.success(request, "Announcement deleted successfully.")
        return redirect('view_announcements')
    return render(request, 'delete_announcement_confirm.html', {'announcement': announcement})
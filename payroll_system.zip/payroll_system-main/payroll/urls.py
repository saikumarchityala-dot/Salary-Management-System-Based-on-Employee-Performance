# payroll/urls.py

from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.custom_logout_view, name='logout'),
    path('admin_dashboard/', views.admin_dashboard_view, name='admin_dashboard'),
    path('employee_dashboard/', views.employee_dashboard_view, name='employee_dashboard'),
    path('add_employee/', views.add_employee_view, name='add_employee'),
    path('weekly_earnings/', views.weekly_earnings_view, name='weekly_earnings'),
    
    path('about/', views.about_us_view, name='about_us'),
    path('contact/', views.contact_us_view, name='contact_us'),
    path('view_employees/', views.view_employees_view, name='view_employees'),
    path('generate_salary_slip/', views.generate_salary_slip_view, name='generate_salary_slip'),
    
    path('mark_attendance/', views.mark_attendance_view, name='mark_attendance'),
    
    path('view_attendance/', views.view_attendance_view, name='view_attendance'),
    
    path('predict_salary/', views.predict_salary_view, name='predict_salary'),
    path('my_salary_slips/', views.my_salary_slips_view, name='my_salary_slips'),
    path('salary_slip/<int:slip_id>/', views.salary_slip_detail_view, name='salary_slip_detail'),
    path('employee/edit/<int:employee_id>/', views.edit_employee_view, name='edit_employee'),
    path('employee/delete/<int:employee_id>/', views.delete_employee_view, name='delete_employee'),
    path('view_slips/', views.admin_view_slips_view, name='admin_view_slips'),
    path('view_slip/<int:slip_id>/', views.admin_salary_slip_detail_view, name='admin_salary_slip_detail'),
    
    path('delete_slip/<int:slip_id>/', views.delete_salary_slip_view, name='delete_salary_slip'),
    path('my_salary_prediction/', views.my_salary_prediction_view, name='my_salary_prediction'),
    path('my_attendance/', views.my_attendance_view, name='my_attendance'),
    
    path('my_profile/', views.my_profile_view, name='my_profile'),

    path('apply_leave/', views.apply_leave_view, name='apply_leave'),
    path('leave_history/', views.leave_history_view, name='leave_history'),
    path('manage_leaves/', views.manage_leaves_view, name='manage_leaves'),
    path('approve_leave/<int:leave_id>/', views.approve_leave_view, name='approve_leave'),
    path('reject_leave/<int:leave_id>/', views.reject_leave_view, name='reject_leave'),

    path('announcements/', views.view_announcements_view, name='view_announcements'),
    path('announcements/create/', views.create_announcement_view, name='create_announcement'),
    path('announcements/delete/<int:announcement_id>/', views.delete_announcement_view, name='delete_announcement'),

]
